PhyziqAi iOS Source (Build 24)
================================

To open:
1. Install Xcode 16+ (iOS 18 SDK).
2. Double-click ios/PhyziqAi.xcodeproj.
3. Select the PhyziqAi scheme and an iPhone simulator, then Run.

Notes:
- AI/subscription features need the Rork toolkit config, which is injected from
  environment variables at build time (see PhyziqAi/Scripts/generate-bundled-config.sh).
  Without them, the app runs in offline/sample mode.
- StoreKit testing config: PhyziqAi/Configuration.storekit (scheme already wired to it).
- HealthKit is read-only by design (iOS 26 crash fix) and disabled on iPad.
